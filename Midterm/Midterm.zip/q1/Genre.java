package q1;

public enum Genre {
	POP(1), ROCK(2), CLASSICAL(3);
	
	private int uniqueID;

	private Genre(int uniqueID) {
		this.uniqueID = uniqueID;
	}

}
