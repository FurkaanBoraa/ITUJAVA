package q1;

public class PlayList {
	private String creator;
	private Song[] song;
	private int songCount = 0;
	private int capacity;
	
	public PlayList(String creator, int capacity) {
		this.creator = creator;
		this.song= new Song[capacity];
		this.capacity = capacity;
	}
	
	public boolean addSong(Song song) {
		if (this.songCount == this.capacity) {
			return false;
		}
		if (this.song == null) {
			this.song[0] = song;
			return true;
		}
		int counter = 0;
		for (int i = 0; i < this.song.length; i++) {
			if (this.song[i]!=null&&this.song[i].getGenre() == song.getGenre()) {
				counter++;
			}			
		}
		if (counter < 2) {
			this.song[songCount] = song;
			this.songCount++;
			return true;
		}
		return false;
	}
	public boolean deleteSong(Song song) {
		for (int i = 0; i < this.song.length; i++) { //Search all songs
			if (this.song[i] == song) {				 //Find the song
				for (int j=i; j < this.song.length; j++){ //To shift songs
					if (j+1<this.song.length) {
						
						this.song[j] = this.song[j+1];
					}else {

						this.song[j]=null;
					}
					
				}
				return true;
			}
		}
		return false;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Song[] getSong() {
		return song;
	}

	public void setSong(Song[] song) {
		this.song = song;
	}

	public int getSongCount() {
		return songCount;
	}

	public void setSongCount(int songCount) {
		this.songCount = songCount;
	}
	
	public void writeSongs() {
		for (int i = 0; i < song.length; i++) {
			try {
				System.out.println(song[i].getTitle() + " - " + song[i].getGenre());
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		}
	}
	
	
	
}
