package q2;

import java.security.SecureRandom;
import java.util.Iterator;

public class Q2 {

	public static void main(String[] args) {
		SecureRandom random = new SecureRandom();
		int[][] A = new int[10][10];
		double[] norms = new double[11];
		norms[0]= -99;
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				A[i][j] = random.nextInt(100)+1; 
			}
		}
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				norms[i+1] += A[i][j]*A[i][j]; 	//Can use Math.pow as well
			}
		}
		for (int i = 1; i < norms.length; i++) {
			norms[i] = Math.sqrt(norms[i]);
			System.out.println("Norm of "+i+"th row is = " + norms[i]);
		}
		double max = norms[1];
		double min = norms[1];
		int maxflag = 0;
		int minflag = 0;
		for (int i = 1; i < norms.length; i++) {
			if (norms[i]> max) {
				max = norms[i];
				maxflag = i;
			}
			if (norms[i]< min) {
				min = norms[i];
				minflag = i;
			}
		}
		int[] temp= A[minflag];
		A[minflag]= A[maxflag];
		A[maxflag]=temp;
		
		
	}

}
