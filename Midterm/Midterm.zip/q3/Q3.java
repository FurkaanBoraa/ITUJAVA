package q3;

import java.security.SecureRandom;

public class Q3 {

	public static int method(int[] array) {
		int counter = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i]>0) {
				counter++;
			}
		}
		return counter;
	}
	public static void main(String[] args) {
		SecureRandom random = new SecureRandom();
		int[] array = new int[500];
		for (int i = 0; i < array.length; i++) {
			array[i] = random.nextInt(2000) - 1000;
		}
		method(array);

	}

}
