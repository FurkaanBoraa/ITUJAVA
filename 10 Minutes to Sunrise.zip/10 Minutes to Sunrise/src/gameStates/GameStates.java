package gameStates;

public enum GameStates {
	PLAYING, MENU, LEVELUP, OPTIONS, QUIT;
	
	public static GameStates state = MENU;
}
