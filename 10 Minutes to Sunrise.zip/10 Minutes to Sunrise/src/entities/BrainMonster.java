package entities;
import static utils.Constants.EnemyConstants.*;
public class BrainMonster extends Enemy{

	public BrainMonster(float x, float y) {
		super(x, y, ENEMY_WIDTH, ENEMY_HEIGHT, 5);
		// TODO Auto-generated constructor stub
	}

}
