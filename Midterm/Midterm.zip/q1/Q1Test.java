package q1;

public class Q1Test {

	public static void main(String[] args) {
		// 3 Classic / 2 Pop / 1 Rock music
		Song song1 = new Song("Experience", Genre.CLASSICAL);
		Song song2 = new Song("Oltremare", Genre.CLASSICAL);
		Song song3 = new Song("Moonlight Orchestra", Genre.CLASSICAL);
		Song song4 = new Song("Cevapsiz Sorular", Genre.POP);
		Song song5 = new Song("Bes", Genre.POP);
		Song song6 = new Song("Tuesday", Genre.ROCK);
	
		System.err.println("I unfortunately write a terrible test class since I have a terrible migraine, sorry :(");
		//Create new Playlist
		PlayList playlist1 = new PlayList("Bora",10);
		//System.out.println(playlist1.getSongCount()); //Currently 0 songs
		
		playlist1.addSong(song1); //Add a classical song
		System.out.println(playlist1.getSongCount()); //Currently 1 songs (classic)
		playlist1.addSong(song2); //Add a classical song
		System.out.println(playlist1.getSongCount()); //Currently 2 songs (classic ,classic)
		playlist1.addSong(song3); //Add a classical song
		System.out.println(playlist1.getSongCount()); //Couldn't add 3rd classic song
		playlist1.writeSongs();
		playlist1.addSong(song4); //Add a pop song
		System.out.println(playlist1.getSongCount()); //Currently 3 songs (classic ,classic, pop)
		playlist1.writeSongs();
		System.out.println("Now delete a song");
		playlist1.deleteSong(song4);
		playlist1.writeSongs();
	
	}

}
